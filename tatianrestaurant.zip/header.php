<div id="header">
	<div class="wrapper">
		<div id="logo"><a href="index.php"></a></div>
		<span id="opennav" style="font-size:30px;cursor:pointer" onclick="openNav()"><i class="fa fa-bars"></i></span>
			<div id="myNav" class="overlay">
  				<a id="closenav" href="javascript:void(0)" class="closebtn" onclick="closeNav()"><i class="fa fa-times"></i></a>
				<div class="overlay-content">
					<ul id="nav">
						<li><a href="index.html">Home</a></li>
						<li><a href="menu.html">Menu</a></li>
						<li><a href="about.html">About Tatian</a></li>
						<li><a href="team.html">Team</a></li>
						<li><a href="news.html">News</a></li>
						<li><a href="contact.html">Contact</a></li>	
					</ul>
				</div>
			</div>
	</div>
</div>