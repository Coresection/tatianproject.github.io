<div id="footerend"><p>Tatian Restaurant © 2018 all rights reserved</p></div>

<script>
function openNav() {
    document.getElementById("myNav").style.width = "100%";
}

function closeNav() {
    document.getElementById("myNav").style.width = "0%";
}
</script>